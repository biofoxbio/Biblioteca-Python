import PySimpleGUI as sg

sg.popup('Hello From PySimpleGUI!', 'This is the shortest GUI program ever!')
