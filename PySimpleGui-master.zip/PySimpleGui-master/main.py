import PySimpleGUI
PySimpleGUI.main()