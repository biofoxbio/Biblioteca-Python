import PySimpleGUI as sg

print=sg.Print
for i in range(100):
    print(i)